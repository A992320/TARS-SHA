<?php
declare(strict_types=1);
require __DIR__.'/../app/ui.php';

$page=(string)($_GET['page']??'home');
if (!in_array($page,['home','tars','shashety','tutorials','watch','downloads','articles','article'],true)) {http_response_code(404);$page='notfound';}

// نموذج تعليقات الفيديو: يتم حفظه بانتظار الموافقة قبل الظهور.
if (request_post() && ($_POST['action']??'')==='comment') {
    verify_csrf();
    $videoId=max(0,(int)($_POST['video_id']??0));
    $video=fetch_one('SELECT id FROM videos WHERE id=? AND published=1',[$videoId]);
    if (!$video) {http_response_code(404);exit('الفيديو غير متاح');}
    if (trim((string)($_POST['website']??''))!=='') redirect('/?page=watch&id='.$videoId);
    $name=trim((string)($_POST['name']??'')); $body=trim((string)($_POST['body']??''));
    $l1=mb_strlen($name,'UTF-8'); $l2=mb_strlen($body,'UTF-8');
    if ($l1<2 || $l1>70 || $l2<3 || $l2>2000) {flash('الاسم 2-70 حرفاً والتعليق 3-2000 حرف.','error');redirect('/?page=watch&id='.$videoId.'#comments');}
    $fingerprint=ip_fingerprint();
    $count=fetch_one('SELECT COUNT(*) AS n FROM comments WHERE ip_hash=? AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)',[$fingerprint]);
    if ((int)$count['n']>=3) {flash('وصلت إلى الحد المسموح للتعليقات. حاول بعد عشر دقائق.','error');redirect('/?page=watch&id='.$videoId.'#comments');}
    $status=setting('comment_moderation','1')==='1'?'pending':'approved';
    exec_sql('INSERT INTO comments(video_id,display_name,body,ip_hash,status) VALUES (?,?,?,?,?)',[$videoId,$name,$body,$fingerprint,$status]);
    flash($status==='pending'?'تم استلام تعليقك، سيظهر بعد موافقة الإدارة.':'تم نشر تعليقك.');
    redirect('/?page=watch&id='.$videoId.'#comments');
}

$pageTitles=['home'=>'','tars'=>'TARS LOADBALANCE','shashety'=>'SHASHETY PRO','tutorials'=>'مكتبة الشروحات','watch'=>'مشاهدة الشرح','downloads'=>'مركز التحميل','articles'=>'المدونة','article'=>'مقال','notfound'=>'الصفحة غير موجودة'];
page_head($pageTitles[$page]??'');nav_public($page);flash_notice();

if ($page==='home'):
$categories=fetch_all('SELECT * FROM categories WHERE visible=1 AND show_on_home=1 ORDER BY sort_order,id LIMIT 12');
$videos=fetch_all('SELECT v.*,c.title AS category_title FROM videos v LEFT JOIN categories c ON c.id=v.category_id WHERE v.published=1 ORDER BY v.featured DESC,v.created_at DESC LIMIT 3');
$downloads=fetch_all('SELECT d.*,a.original_name,a.size_bytes FROM downloads d JOIN assets a ON a.id=d.asset_id WHERE d.published=1 ORDER BY d.featured DESC,d.created_at DESC LIMIT 4');
$articles=fetch_all('SELECT a.*,c.title AS category_title FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.published=1 ORDER BY a.featured DESC,a.created_at DESC LIMIT 3');
?>
<main class="fusion-site">
  <section class="fusion-hero" aria-labelledby="fusion-title">
    <div class="fusion-halves" aria-hidden="true">
      <div class="fusion-side media-side">
        <div class="media-aura"></div><div class="media-orbit orbit-one"></div><div class="media-orbit orbit-two"></div>
        <div class="entertainment-device">
          <div class="device-top"><div class="device-brand"><span class="play-mark">▶</span> SHASHTY <b>PRO</b></div><span class="device-status">● STREAMING</span></div>
          <div class="device-content">
            <div class="device-menu"><span class="current">⌂</span><span>▦</span><span>▣</span><span>♡</span><span>☰</span></div>
            <div class="device-main"><div class="device-feature"><span class="scene-badge">CINEMA EXPERIENCE</span><div class="scene-text"><strong>عالم من الترفيه</strong><span>مشاهدة • بث مباشر • مكتبة</span><div><i>4K</i><i>HDR</i><i>LIVE</i></div></div><span class="scene-play">▶</span></div><div class="device-thumbnails"><span class="thumb-one"></span><span class="thumb-two"></span><span class="thumb-three"></span><span class="thumb-four"></span></div></div>
          </div>
          <div class="device-foot"><span class="signal">◉</span><span>HLS · DASH · XTREAM</span><span>SMART TV</span></div>
        </div>
        <div class="media-caption"><span class="film-mark">▱</span><strong>SHASHTY <em>PRO</em></strong><small>STREAMING PLATFORM</small></div>
      </div>
      <div class="fusion-side tech-side">
        <div class="tech-grid"></div><div class="tech-aura"></div>
        <div class="server-rack" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span></div>
        <div class="wan-device">
          <div class="wan-header"><div><span class="tars-brand-mark">T</span><strong>TARS <small>LOADBALANCE</small></strong></div><span class="demo-badge">● UI CONCEPT</span></div>
          <div class="wan-top"><div class="wan-rows"><span class="wan-title">WAN CONNECTIONS</span><div><b>WAN 01</b><span class="connected">● ACTIVE</span></div><div><b>WAN 02</b><span class="connected">● ACTIVE</span></div><div><b>WAN 03</b><span class="connected">● ACTIVE</span></div><div><b>WAN 04</b><span class="standby">○ STANDBY</span></div></div>
            <div class="wan-chart"><span>NETWORK TRAFFIC</span><svg viewBox="0 0 240 112" preserveAspectRatio="none" role="presentation"><path d="M0 15H240 M0 42H240 M0 70H240 M0 97H240" stroke="#264459" stroke-width="1"/><path d="M0 88L24 62L48 68L72 42L96 59L120 31L144 44L168 18L192 32L216 13L240 20" stroke="#29e8ee" fill="none" stroke-width="3" stroke-linejoin="round"/><path d="M0 94L24 84L48 96L72 72L96 82L120 61L144 70L168 51L192 65L216 45L240 55" stroke="#ab77ff" fill="none" stroke-width="2" stroke-linejoin="round"/></svg><div class="chart-key"><small>● DOWNLOAD</small><small>● UPLOAD</small></div></div>
          </div>
          <div class="wan-bottom"><div class="wan-gauge"><span class="mini-gauge"></span><div><strong>SMART</strong><small>ROUTING</small></div></div><div class="wan-routes"><span>POLICY ENGINE</span><div><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div><small>Adaptive WAN distribution</small></div></div>
        </div>
        <div class="tech-caption"><span class="tars-brand-mark">T</span><strong>TARS</strong><small>NETWORK INTELLIGENCE</small></div>
      </div>
    </div>
    <div class="fusion-centerline" aria-hidden="true"><span class="fusion-electric"></span></div>
    <div class="fusion-heading container">
      <span class="fusion-eyebrow"><span class="pulse"></span><?=e(setting('announcement','منصة الحلول المتقدمة'))?></span>
      <p class="fusion-kicker">TWO SYSTEMS · ONE PLATFORM</p>
      <h1 id="fusion-title"><?=e(setting('hero_title','اتحاد الأنظمة الذكي'))?></h1>
      <p class="fusion-subtitle"><?=e(setting('hero_description','منصة موحدة تجمع TARS LOADBALANCE لإدارة الشبكات مع SHASHTY PRO IPTV للبث والمشاهدة، في تجربة احترافية واحدة.'))?></p>
      <div class="hero-actions"><a class="btn btn-primary" href="/?page=downloads"><span>↓</span> تحميل الأنظمة</a><a class="btn btn-outline" href="/?page=tutorials"><span>▷</span> استعرض الشروحات</a></div>
    </div>
    <div class="hero-bottom container"><div class="feature-track streaming-track"><span>◉ HLS</span><span>▥ DASH</span><span>▷ XTREAM</span><span>▣ 4K</span><span>☷ الترجمة</span><span>▢ Smart TV</span></div><div class="fusion-link" aria-label="اتحاد النظامين">∞</div><div class="feature-track network-track"><span>Multi-WAN</span><span>MACVLAN</span><span>VLAN</span><span>Ethernet</span><span>WireGuard</span><span>Failover</span></div></div>
  </section>
  <section class="ecosystem-section container" id="projects">
    <div class="center-intro"><span class="eyebrow">THE UNIFIED ECOSYSTEM</span><h2>منصة واحدة. <span>قوتان مختلفتان.</span></h2><p>تجربة شاشتي السينمائية تلتقي بذكاء إدارة الشبكات في تارس — كل مشروع بهويته وتقنياته، تحت سقف واحد.</p></div>
    <div class="system-duo">
      <a href="/?page=shashety" class="system-card shashty-system"><div class="system-header"><span class="system-identity"><span class="round-logo play-logo">▶</span> SHASHTY <b>PRO</b></span><span class="system-link">↗</span></div><div class="system-copy"><span class="system-tag">STREAMING / IPTV</span><h3>المشاهدة مثل ما تتخيلها</h3><p>مكتبة قنوات وأفلام ومسلسلات، تشغيل HLS وDASH، Xtream، الترجمات، والتحكم الذكي بالأجهزة.</p></div><div class="system-chips"><span>▷ مشغل HLS</span><span>◉ Xtream</span><span>▣ جودة 4K</span><span>☷ ترجمات</span><span>▢ Smart TV</span></div><div class="system-bottom">اكتشف مميزات شاشتي برو <span>←</span></div></a>
      <a href="/?page=tars" class="system-card tars-system"><div class="system-header"><span class="system-identity"><span class="round-logo tars-logo">T</span> TARS <small>LOADBALANCE</small></span><span class="system-link">↗</span></div><div class="system-copy"><span class="system-tag">NETWORK / MULTI-WAN</span><h3>سيطرة أذكى على كل خط</h3><p>إدارة اتصال Multi-WAN مع VLAN وMACVLAN ومنافذ Ethernet وL2TP وWireGuard وسياسات ذكية للتنزيل والرفع.</p></div><div class="system-chips"><span>↔ Multi-WAN</span><span>◇ MACVLAN</span><span>▦ VLAN</span><span>⇅ Smart WAN</span><span>⬡ WireGuard</span></div><div class="system-bottom">اكتشف مميزات تارس <span>←</span></div></a>
    </div>
  </section>
  <section class="fusion-tools">
   <div class="container"><div class="section-line"><?php section_intro('CONTROL / CONTENT / RELEASES','منصة إدارة بلا تعقيد','إدارة محتوى البوابة من مكان واحد: الأقسام، الشروحات، الملفات، والإصدارات.');?><a class="text-link" href="/admin.php">لوحة الإدارة ↗</a></div><div class="tools-layout"><div class="admin-showcase"><div class="showcase-window"><div class="showcase-toolbar"><span class="traffic-lights"><i></i><i></i><i></i></span><span>ADMIN CONTROL CENTER</span><span>•••</span></div><div class="showcase-body"><aside><span class="admin-dot">T</span><i class="on"></i><i></i><i></i><i></i><i></i></aside><div class="showcase-screen"><div class="screen-eyebrow">PORTAL OVERVIEW</div><h4>لوحة تحكم موحّدة</h4><div class="screen-metrics"><span><b>▦</b><small>الأقسام</small></span><span><b>▶</b><small>الفيديوهات</small></span><span><b>↓</b><small>الإصدارات</small></span></div><div class="screen-list"><span></span><span></span><span></span><span></span></div></div></div></div></div><div class="tool-features"><div><span>▤</span><strong>إنشاء الأقسام</strong><small>تظهر مباشرة في الرئيسية</small></div><div><span>▶</span><strong>رفع MP4 / MKV</strong><small>مكتبة الشروحات والفيديو</small></div><div><span>↓</span><strong>رفع ISO / EXE</strong><small>إصدارات وتحميلات محلية</small></div><div><span>☷</span><strong>إدارة التعليقات</strong><small>مراجعة ونشر التعليقات</small></div><div><span>▦</span><strong>قاعدة MySQL</strong><small>إدارة البيانات بشكل منظم</small></div><div><span>◈</span><strong>كتابة المقالات</strong><small>أخبار وتحديثات ودروس</small></div></div></div></div>
  </section>
  <section class="container content-section" id="downloads"><div class="section-line"><?php section_intro('DOWNLOAD CENTER / OFFICIAL BUILDS','مركز تحميل الأنظمة','الإصدارات الحقيقية التي تنشرها من لوحة الإدارة فقط، مع رقم النسخة والحجم والوصف.');?><a class="text-link" href="/?page=downloads">كل التحميلات ←</a></div>
  <?php if($downloads):?><div class="downloads-list enhanced-downloads"><?php foreach($downloads as $d) download_card($d);?></div><?php else:?>
    <div class="download-duo"><div class="download-product tars-download"><span class="download-brand"><b>T</b> TARS LOADBALANCE</span><div class="download-cloud">↓</div><h3>نظام الشبكات والدمج الذكي</h3><p>سيظهر أحدث إصدار TARS هنا عند رفع النسخة من لوحة الإدارة.</p><a class="btn btn-outline" href="/?page=downloads&amp;product=tars">عرض إصدارات TARS ←</a><small>لم يتم نشر ملف للتحميل بعد</small></div><div class="download-product shashty-download"><span class="download-brand"><b>▶</b> SHASHTY PRO</span><div class="download-cloud">↓</div><h3>نظام البث والمشاهدة</h3><p>سيظهر أحدث إصدار شاشتي برو هنا عند رفع النسخة من لوحة الإدارة.</p><a class="btn btn-outline" href="/?page=downloads&amp;product=shashety">عرض إصدارات شاشتي ←</a><small>لم يتم نشر ملف للتحميل بعد</small></div></div>
  <?php endif;?></section>
  <section class="section-alt categories-section" id="categories"><div class="container"><?php section_intro('LEARN / BUILD / DISCOVER','أقسام وشروحات متجددة','كل قسم تضيفه وتفعّله من لوحة الإدارة يظهر هنا دون تعديل البرمجة.');?><div class="categories-grid"><?php foreach($categories as $c) category_card($c);?></div></div></section>
  <section class="container content-section" id="tutorials"><div class="section-line"><?php section_intro('TUTORIALS / VIDEO LIBRARY','الشروحات المرئية','من أساسيات دمج الخطوط إلى إدارة محتوى شاشتي برو.');?><a class="text-link" href="/?page=tutorials">استعرض الشروحات ←</a></div><?php if($videos):?><div class="content-grid"><?php foreach($videos as $v) video_card($v);?></div><?php else:?><div class="empty-state"><span>▷</span><h3>مكتبة الشروحات جاهزة</h3><p>ارفع أول فيديو MP4 أو MKV من لوحة الإدارة ليظهر هنا.</p><a class="btn btn-outline" href="/?page=tutorials">فتح مكتبة الشروحات</a></div><?php endif;?></section>
  <?php if($articles):?><section class="section-alt"><div class="container content-section"><div class="section-line"><?php section_intro('JOURNAL / PRODUCT UPDATES','المقالات والتحديثات','كل جديد في النظامين والملاحظات التقنية.');?><a class="text-link" href="/?page=articles">كل المقالات ←</a></div><div class="content-grid"><?php foreach($articles as $a) article_card($a);?></div></div></section><?php endif;?>
  <section class="container cta-wrap"><div class="cta-block fusion-cta"><div><span class="eyebrow">TARS × SHASHTY PRO</span><h2>مستقبل شبكتك ومحتواك، في منصة واحدة.</h2><p>ابدأ بالتحميل أو تعلم من الشروحات، وتابع تحديثات النظامين من مكان واحد.</p></div><div class="cta-buttons"><a href="/?page=downloads" class="btn btn-white">مركز التحميل ↓</a><a href="/?page=tutorials" class="btn btn-outline-white">الشروحات ▶</a></div></div></section>
</main>
<?php elseif ($page==='tars'): ?>
<main><section class="inner-hero tars-inner"><div class="container"><span class="eyebrow">TARS / NETWORK INTELLIGENCE</span><h1>TARS <span>LOADBALANCE</span></h1><p>مشروع إدارة شبكات متعدد الاتصالات، صُمّم ليجمع إعداد الواجهات والتوجيه ومراقبة الجودة في بيئة واحدة.</p><div class="hero-actions"><a class="btn btn-primary" href="/?page=downloads&amp;product=tars">إصدارات TARS ↓</a><a class="btn btn-outline" href="/?page=tutorials&amp;product=tars">شروحات الدمج ↗</a></div></div></section>
<section class="container content-section"><?php section_intro('NETWORK FEATURES','الخصائص ومكوّنات النظام','الخصائص أدناه تصف أهداف المشروع ووحداته المخطط لها؛ يعتمد توفر كل وظيفة على إصدار النظام الذي يتم نشره.');?><div class="feature-grid">
<?php foreach([
 ['◉','Multi-WAN','ربط عدة خطوط ومزوّدي خدمة، مع متابعة منفصلة لصحة كل اتصال.'],
 ['⇄','Smart Load Balancing','توزيع الاتصالات حسب الوزن، الأداء، والاستقرار مع إمكانية تغيير سياسات التوجيه.'],
 ['↓','Download / Upload','سياسات مستقلة لترافيك التنزيل والرفع، وربط الجلسات بالمسار المناسب.'],
 ['⬡','VLAN / MACVLAN','تجهيز الشبكات الافتراضية والواجهات المنطقية إلى جانب منافذ Ethernet.'],
 ['⇌','PPPoE / DHCP / Static','تجهيز منافذ الإنترنت بطرق اتصال متعددة حسب مزود الخدمة.'],
 ['▣','Ethernet Direct','تشغيل منافذ الشبكة الفيزيائية كواجهات WAN مستقلة ومباشرة.'],
 ['🔒','L2TP / WireGuard','دعم الأنفاق والربط الآمن ضمن تصميم متعدد الواجهات.'],
 ['⌁','Failover & Health Monitor','مراقبة الاستجابة وفقدان الحزم والتحويل التلقائي عند تراجع جودة المسار.'],
 ['✧','Dynamic Weights','أوزان قابلة للتعديل تعتمد على جودة الخط والسرعة ومؤشرات الازدحام.'],
 ['◷','Quality Monitoring','متابعة زمن الاستجابة وفقدان الحزم لكل خط وإظهار التغيرات.'],
 ['⇥','Sticky Sessions','تثبيت اتصال المستخدم على مسار واحد لتقليل مشاكل الجلسات الحساسة.'],
 ['⚙','Traffic Policies','ملفات تعريف للألعاب والتنزيل، وثبات المسار للجلسات الحساسة.']
] as $f):?><div class="feature-card"><span class="feature-icon"><?=e($f[0])?></span><h3><?=e($f[1])?></h3><p><?=e($f[2])?></p></div><?php endforeach;?></div>
<div class="info-banner"><strong>معلومة تقنية مهمة</strong><p>التوزيع الذكي بين عدة اتصالات لا يعني بالضرورة جمع سرعاتها في اتصال TCP واحد. الاستفادة من مجموع الخطوط عادة تكون عبر اتصالات متوازية، أما تجميع جلسة واحدة فيتطلب تقنية تجميع طرفي خاصة ودعماً في الجهتين.</p></div></section></main>
<?php elseif($page==='shashety'): ?>
<main><section class="inner-hero shashety-inner"><div class="container"><span class="eyebrow">SHASHETY PRO / ENTERTAINMENT TECHNOLOGY</span><h1>SHASHETY <span>PRO IPTV</span></h1><p>منصة تجربة مشاهدة طوّرتها حول مشغّل متقدم، تصفح القنوات والمحتوى، وتحكم يناسب الهاتف والكمبيوتر وأجهزة التلفاز.</p><div class="hero-actions"><a class="btn btn-primary" href="/?page=downloads&amp;product=shashety">تحميل شاشتي ↓</a><a class="btn btn-outline" href="/?page=tutorials&amp;product=shashety">شروحات شاشتي ↗</a></div></div></section><section class="container content-section"><?php section_intro('STREAMING EXPERIENCE','مميزات شاشتي برو','تعريف بالمكوّنات والوظائف التي عملت عليها في مشروع شاشتي؛ قد تختلف بحسب الإصدار والمنصة.');?><div class="feature-grid">
<?php foreach([
 ['▶','HLS.js Playback','مشغل ويب يدعم بث HLS والتحكم في التشغيل والجودة.'],
 ['▣','Picture-in-Picture','وضع صورة داخل صورة، ووضع المسرح للعرض الموسّع.'],
 ['◷','Sleep Timer','مؤقت إيقاف مع خيارات سرعة العرض والتشغيل التلقائي.'],
 ['☼','Dark / Light Themes','تصميم متجاوب مع وضع داكن وفاتح وتحكم بالمظهر.'],
 ['↔','Mobile Gestures','إيماءات الهاتف وواجهة ملائمة للشاشات المختلفة.'],
 ['▤','Subtitles','رفع ملفات ترجمة SRT وASS وVTT، وأدوات تحرير وترجمة.'],
 ['⌕','Library & Search','قوائم أقسام وبحث وتصفح تفاصيل المحتوى.'],
 ['✥','Admin & Storage','إدارة الملفات والتخزين وتوزيع البيانات عبر الأقراص في بيئات الاستضافة.'],
 ['◇','Hybrid Web / PHP','واجهة ويب متكاملة مع API ونظام إدارة المحتوى.'],
 ['✳','Xtream & M3U','حسابات Xtream متعددة وقوائم M3U مع إدارة القنوات والمكتبة.'],
 ['▥','EPG Guide','دليل برامج القنوات ومعلومات البث الحالي والقادم في الإصدارات الداعمة.'],
 ['↻','ReStream Engine','أدوات إعادة البث ومراقبة اتصال القناة في الإصدارات الداعمة.'],
 ['☷','Subtitle Tools','ملفات SRT وASS وVTT مع ربط خدمات ترجمة عند إضافة مفاتيح API.']
] as $f):?><div class="feature-card"><span class="feature-icon"><?=e($f[0])?></span><h3><?=e($f[1])?></h3><p><?=e($f[2])?></p></div><?php endforeach;?></div><div class="info-banner"><strong>عن المحتوى</strong><p>هذه البوابة تعرض معلومات المشروع والشروحات والتنزيلات التي تنشرها الإدارة. ليست خادم بث IPTV أو مشغلاً متكاملاً بحد ذاتها، ولا تتضمن قنوات أو مواد غير مرخصة.</p></div></section></main>
<?php elseif($page==='tutorials'):
$cid=max(0,(int)($_GET['category']??0));$product=(string)($_GET['product']??'');$search=trim((string)($_GET['q']??''));
$where=['v.published=1'];$params=[];
if($cid){$where[]='v.category_id=?';$params[]=$cid;}
if(in_array($product,['tars','shashety','general'],true)){$where[]='c.product=?';$params[]=$product;}
if($search!==''){$where[]='(v.title LIKE ? OR v.description LIKE ?)';$params[]='%'.$search.'%';$params[]='%'.$search.'%';}
$videos=fetch_all('SELECT v.*,c.title AS category_title FROM videos v LEFT JOIN categories c ON c.id=v.category_id WHERE '.implode(' AND ',$where).' ORDER BY v.featured DESC,v.created_at DESC LIMIT 100',$params);
$cats=fetch_all('SELECT * FROM categories WHERE visible=1 ORDER BY sort_order');?>
<main><section class="page-banner container"><span class="eyebrow">TUTORIAL LIBRARY / VIDEOS</span><h1>مكتبة <span>الشروحات</span></h1><p>دروس الدمج والشبكات وشاشتي برو، منشورة مباشرة من لوحة الإدارة.</p></section><section class="container content-section"><form method="get" class="filter-form"><input type="hidden" name="page" value="tutorials"><input type="search" name="q" placeholder="ابحث عن شرح أو موضوع..." value="<?=e($search)?>"><select name="category"><option value="0">جميع الأقسام</option><?php foreach($cats as $c):?><option value="<?=(int)$c['id']?>"<?=selected($cid,$c['id'])?>><?=e($c['title'])?></option><?php endforeach;?></select><select name="product"><option value="">كل المشاريع</option><option value="tars"<?=selected($product,'tars')?>>TARS</option><option value="shashety"<?=selected($product,'shashety')?>>شاشتي برو</option></select><button class="btn btn-primary" type="submit">بحث</button></form><?php if($videos):?><div class="content-grid"><?php foreach($videos as $v)video_card($v);?></div><?php else:?><div class="empty-state"><span>▷</span><h3>لا توجد شروحات مطابقة</h3><p>جرّب تغيير عوامل البحث أو ارفع الفيديوهات من لوحة الإدارة.</p></div><?php endif;?></section></main>
<?php elseif($page==='watch'):
$id=max(0,(int)($_GET['id']??0));
$v=fetch_one('SELECT v.*,c.title AS category_title,a.original_name,a.mime,a.size_bytes FROM videos v JOIN assets a ON a.id=v.asset_id LEFT JOIN categories c ON c.id=v.category_id WHERE v.id=? AND v.published=1',[$id]);
if(!$v){http_response_code(404);?><main><section class="container content-section"><div class="empty-state"><h2>هذا الشرح غير موجود</h2><a href="/?page=tutorials" class="btn btn-primary">عرض الشروحات</a></div></section></main><?php }else{
exec_sql('UPDATE videos SET views=views+1 WHERE id=?',[$id]);
$comments=fetch_all('SELECT display_name,body,created_at FROM comments WHERE video_id=? AND status="approved" ORDER BY created_at DESC LIMIT 100',[$id]);
?><main><section class="container watch-wrap"><a href="/?page=tutorials" class="backlink">→ العودة إلى الشروحات</a><div class="watch-grid"><article><div class="player-frame"><video controls preload="metadata" playsinline controlslist="nodownload" src="/media.php?id=<?=$id?>">المتصفح لا يدعم عرض هذا الفيديو مباشرة.</video></div><div class="watch-content"><span class="tag"><?=e($v['category_title']??'شروحات')?></span><h1><?=e($v['title'])?></h1><div class="watch-meta"><span>◷ <?=pretty_date($v['created_at'])?></span><span>◉ <?=number_format((int)$v['views']+1)?> مشاهدة</span><span>◈ <?=e(strtoupper(pathinfo($v['original_name'],PATHINFO_EXTENSION)))?></span></div><p class="rich-copy"><?=nl($v['description'])?></p><?php if(strtolower(pathinfo($v['original_name'],PATHINFO_EXTENSION))==='mkv'):?><div class="info-banner"><strong>تنبيه MKV</strong><p>بعض المتصفحات لا تدعم ملف MKV أو ترميزه. يمكنك تنزيل الفيديو وتشغيله بمشغّل يدعم الصيغة مثل VLC.</p></div><?php endif;?><a class="btn btn-outline" href="/media.php?id=<?=$id?>&amp;download=1">↓ تنزيل الفيديو</a></div>
<div id="comments" class="comments-block"><h2>التعليقات <small>(<?=count($comments)?>)</small></h2><div class="comments-list"><?php if(!$comments):?><p class="muted">كن أول من يترك تعليقاً.</p><?php endif;foreach($comments as $co):?><div class="comment"><div class="avatar"><?=e(mb_substr($co['display_name'],0,1,'UTF-8'))?></div><div><div class="comment-line"><strong><?=e($co['display_name'])?></strong><small><?=pretty_date($co['created_at'])?></small></div><p><?=nl($co['body'])?></p></div></div><?php endforeach;?></div><form class="comment-form" method="post" action="/?page=watch&amp;id=<?=$id?>#comments"><?=csrf_field()?><input type="hidden" name="action" value="comment"><input type="hidden" name="video_id" value="<?=$id?>"><div class="trap"><label>اترك هذا الحقل فارغاً<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div><label>اسمك<input type="text" name="name" required minlength="2" maxlength="70" placeholder="الاسم"></label><label>التعليق<textarea name="body" required minlength="3" maxlength="2000" rows="5" placeholder="اكتب رأيك أو سؤالك..."></textarea></label><p class="muted small">قد يخضع التعليق لمراجعة الإدارة قبل نشره.</p><button class="btn btn-primary" type="submit">إرسال التعليق ←</button></form></div></article><aside class="watch-aside"><span class="eyebrow">MORE TO EXPLORE</span><h3>شروحات أخرى</h3><?php $more=fetch_all('SELECT id,title,created_at FROM videos WHERE published=1 AND id<>? ORDER BY created_at DESC LIMIT 5',[$id]);foreach($more as $m):?><a class="aside-item" href="/?page=watch&amp;id=<?=(int)$m['id']?>"><span>▶</span><div><strong><?=e($m['title'])?></strong><small><?=pretty_date($m['created_at'])?></small></div></a><?php endforeach;?></aside></div></section></main><?php }
?>
<?php elseif($page==='downloads'):
$product=(string)($_GET['product']??'');$search=trim((string)($_GET['q']??''));$where=['d.published=1'];$params=[];
if(in_array($product,['tars','shashety','tools'],true)){$where[]='d.product=?';$params[]=$product;}
if($search!==''){$where[]='(d.title LIKE ? OR d.description LIKE ?)';$params[]='%'.$search.'%';$params[]='%'.$search.'%';}
$ds=fetch_all('SELECT d.*,a.original_name,a.size_bytes FROM downloads d JOIN assets a ON a.id=d.asset_id WHERE '.implode(' AND ',$where).' ORDER BY d.featured DESC,d.created_at DESC LIMIT 100',$params);
?><main><section class="page-banner container"><span class="eyebrow">DOWNLOAD CENTER / RELEASES</span><h1>مركز <span>التحميل</span></h1><p>تنزيل ملفات الأنظمة والإصدارات والبرامج، مع الوصف والحجم ورقم النسخة.</p></section><section class="container content-section"><form class="filter-form" method="get"><input type="hidden" name="page" value="downloads"><input type="search" name="q" value="<?=e($search)?>" placeholder="البحث عن نظام أو إصدار..."><select name="product"><option value="">جميع الأنظمة</option><?php foreach(['tars'=>'TARS','shashety'=>'شاشتي برو','tools'=>'برامج وأدوات'] as $k=>$t):?><option value="<?=e($k)?>"<?=selected($product,$k)?>><?=e($t)?></option><?php endforeach;?></select><button type="submit" class="btn btn-primary">بحث</button></form><?php if($ds):?><div class="downloads-list"><?php foreach($ds as $d)download_card($d);?></div><?php else:?><div class="empty-state"><span>↓</span><h3>لا توجد ملفات منشورة حالياً</h3><p>عند إضافة ملفات جديدة ستظهر هنا مباشرة.</p></div><?php endif;?></section></main>
<?php elseif($page==='articles'):
$articles=fetch_all('SELECT a.*,c.title AS category_title FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.published=1 ORDER BY a.featured DESC,a.created_at DESC LIMIT 100');
?><main><section class="page-banner container"><span class="eyebrow">TECH JOURNAL</span><h1>مقالات <span>وتحديثات</span></h1><p>إرشادات وملاحظات تقنية وأخبار تطوير المشاريع.</p></section><section class="container content-section"><?php if($articles):?><div class="content-grid"><?php foreach($articles as $a)article_card($a);?></div><?php else:?><div class="empty-state"><h3>لا توجد مقالات منشورة</h3></div><?php endif;?></section></main>
<?php elseif($page==='article'):
$a=fetch_one('SELECT a.*,c.title AS category_title FROM articles a LEFT JOIN categories c ON c.id=a.category_id WHERE a.id=? AND a.published=1',[max(0,(int)($_GET['id']??0))]);
?><main><section class="container article-wrap"><?php if($a):?><a class="backlink" href="/?page=articles">→ العودة إلى المدونة</a><span class="eyebrow"><?=e($a['category_title']??'المعرفة')?></span><h1><?=e($a['title'])?></h1><p class="article-summary"><?=e($a['summary'])?></p><div class="watch-meta">◷ <?=pretty_date($a['created_at'])?></div><div class="article-content"><?=nl($a['content'])?></div><?php else:http_response_code(404);?><div class="empty-state"><h2>المقال غير موجود</h2></div><?php endif;?></section></main>
<?php else: ?><main><section class="container content-section"><div class="empty-state"><h1>404</h1><h2>الصفحة غير موجودة</h2><a href="/" class="btn btn-primary">العودة للرئيسية</a></div></section></main>
<?php endif;public_footer();
