<?php
declare(strict_types=1);
require __DIR__.'/../../app/bootstrap.php';
if(!request_post()) json_response(['ok'=>false,'error'=>'POST required'],405);
if(!admin_id()) json_response(['ok'=>false,'error'=>'يرجى تسجيل الدخول مجدداً'],401);
if(!hash_equals(csrf_token(),(string)($_POST['csrf']??''))) json_response(['ok'=>false,'error'=>'رمز الحماية غير صالح'],419);

$action=(string)($_POST['action']??'');
$chunkSize=4*1024*1024;
$maxBytes=max(1,min(128,(int)config('MAX_UPLOAD_GB','16')))*1024*1024*1024;
$extensions=['video'=>['mp4','mkv','webm'],'download'=>['iso','exe','msi','zip','7z','rar','deb','rpm','apk','img','qcow2','ova','vhdx','tar','gz','tgz','pdf','rsc','sh','bin','appimage']];
$mimeMap=['mp4'=>'video/mp4','mkv'=>'video/x-matroska','webm'=>'video/webm'];
try {
    if($action==='start') {
        $type=(string)($_POST['type']??'');$name=basename(str_replace('\\','/',trim((string)($_POST['name']??''))));
        $size=(int)($_POST['size']??0);$ext=strtolower(pathinfo($name,PATHINFO_EXTENSION));
        if(!isset($extensions[$type])||!in_array($ext,$extensions[$type],true)||mb_strlen($name)>255||$size<=0||$size>$maxBytes) throw new RuntimeException('نوع الملف غير مسموح أو الحجم يتجاوز الحد المسموح.');
        $id=bin2hex(random_bytes(16));$total=(int)ceil($size/$chunkSize);
        if(!is_dir(PRIVATE_DIR.'/temp')||!is_writable(PRIVATE_DIR.'/temp'))throw new RuntimeException('مجلد الملفات المؤقتة غير قابل للكتابة.');
        if(file_put_contents(PRIVATE_DIR.'/temp/'.$id.'.part','')===false)throw new RuntimeException('تعذر إنشاء الملف المؤقت.');
        exec_sql('INSERT INTO upload_jobs(id,owner_id,asset_type,original_name,extension,expected_bytes,total_chunks) VALUES (?,?,?,?,?,?,?)',[$id,admin_id(),$type,$name,$ext,$size,$total]);
        json_response(['ok'=>true,'id'=>$id,'chunk_size'=>$chunkSize,'total_chunks'=>$total]);
    }
    $id=(string)($_POST['id']??'');
    if(!preg_match('/^[a-f0-9]{32}$/',$id)) throw new RuntimeException('معرّف الرفع غير صحيح.');
    if($action==='chunk') {
        if(!isset($_FILES['chunk'])||$_FILES['chunk']['error']!==UPLOAD_ERR_OK)throw new RuntimeException('فشل استقبال الجزء، راجع إعدادات PHP للرفع.');
        $size=(int)$_FILES['chunk']['size'];$index=(int)($_POST['index']??-1);
        if($size<=0||$size>$chunkSize||$index<0)throw new RuntimeException('حجم الجزء أو رقمه غير صحيح.');
        db()->beginTransaction();
        try {
            $row=fetch_one('SELECT * FROM upload_jobs WHERE id=? AND owner_id=? FOR UPDATE',[$id,admin_id()]);
            if(!$row || $index >= (int)$row['total_chunks']) throw new RuntimeException('جلسة الرفع غير موجودة أو انتهت.');
            $expectedSize=$index===(int)$row['total_chunks']-1 ? (int)$row['expected_bytes']-((int)$row['total_chunks']-1)*$chunkSize : $chunkSize;
            if($size!==$expectedSize)throw new RuntimeException('حجم الجزء غير مكتمل.');
            // If the client lost the HTTP response after a successful append,
            // acknowledge an identical-size retry for the previous chunk.
            if($index === (int)$row['next_index']-1) {
                db()->commit();
                json_response(['ok'=>true,'received'=>(int)$row['received_bytes'],'next'=>(int)$row['next_index']]);
            }
            if($index!==(int)$row['next_index'] || (int)$row['received_bytes']+$size>(int)$row['expected_bytes'])throw new RuntimeException('اختلاف في تسلسل الأجزاء. أعد الرفع من البداية.');
            $path=PRIVATE_DIR.'/temp/'.$id.'.part';$target=fopen($path,'c+b');
            if(!$target)throw new RuntimeException('تعذر فتح الملف المؤقت.');
            if(!flock($target,LOCK_EX)){fclose($target);throw new RuntimeException('تعذر قفل الملف.');}
            fseek($target,0,SEEK_END);
            if(ftell($target)!==(int)$row['received_bytes']){flock($target,LOCK_UN);fclose($target);throw new RuntimeException('حدث عدم تطابق أثناء النقل.');}
            $source=fopen($_FILES['chunk']['tmp_name'],'rb');
            if(!$source){flock($target,LOCK_UN);fclose($target);throw new RuntimeException('تعذر قراءة الجزء.');}
            $written=stream_copy_to_stream($source,$target,$size);fclose($source);fflush($target);flock($target,LOCK_UN);fclose($target);
            if($written!==$size)throw new RuntimeException('فشل كتابة الجزء كاملاً.');
            exec_sql('UPDATE upload_jobs SET received_bytes=received_bytes+?,next_index=next_index+1 WHERE id=?',[$size,$id]);
            db()->commit();
            json_response(['ok'=>true,'received'=>(int)$row['received_bytes']+$size,'next'=>$index+1]);
        }catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}
    }
    if($action==='finish') {
        db()->beginTransaction();
        try {
            $row=fetch_one('SELECT * FROM upload_jobs WHERE id=? AND owner_id=? FOR UPDATE',[$id,admin_id()]);
            if(!$row||(int)$row['received_bytes']!==(int)$row['expected_bytes']||(int)$row['next_index']!==(int)$row['total_chunks'])throw new RuntimeException('لم تصل كل الأجزاء بعد.');
            $source=PRIVATE_DIR.'/temp/'.$id.'.part';
            if(!is_file($source)||filesize($source)!==(int)$row['expected_bytes'])throw new RuntimeException('حجم الملف النهائي غير مطابق.');
            $sub=$row['asset_type']==='video'?'videos':'downloads';$relative=$sub.'/'.$id.'.'.$row['extension'];
            if(!@rename($source,PRIVATE_DIR.'/'.$relative))throw new RuntimeException('تعذر نقل الملف إلى مكتبة التخزين.');
            $mime=$mimeMap[$row['extension']]??'application/octet-stream';
            exec_sql('INSERT INTO assets(id,owner_id,asset_type,original_name,stored_path,mime,size_bytes) VALUES(?,?,?,?,?,?,?)',[$id,admin_id(),$row['asset_type'],$row['original_name'],$relative,$mime,$row['expected_bytes']]);
            exec_sql('DELETE FROM upload_jobs WHERE id=?',[$id]);
            db()->commit();
            json_response(['ok'=>true,'asset_id'=>$id,'name'=>$row['original_name'],'size'=>$row['expected_bytes']]);
        }catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}
    }
    if($action==='abort') {
        $row=fetch_one('SELECT id FROM upload_jobs WHERE id=? AND owner_id=?',[$id,admin_id()]);
        if($row){exec_sql('DELETE FROM upload_jobs WHERE id=?',[$id]);@unlink(PRIVATE_DIR.'/temp/'.$id.'.part');}
        json_response(['ok'=>true]);
    }
    throw new RuntimeException('إجراء رفع غير مدعوم.');
}catch(Throwable $ex){
    $message=$ex instanceof PDOException?'خطأ في قاعدة البيانات خلال الرفع.':$ex->getMessage();
    json_response(['ok'=>false,'error'=>$message],400);
}
