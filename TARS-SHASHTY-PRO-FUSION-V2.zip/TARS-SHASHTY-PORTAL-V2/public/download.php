<?php
declare(strict_types=1);
require __DIR__.'/../app/stream.php';
$id=max(0,(int)($_GET['id']??0));
$d=fetch_one('SELECT d.published,a.* FROM downloads d JOIN assets a ON a.id=d.asset_id WHERE d.id=?',[$id]);
if(!$d||(!(int)$d['published']&&!admin_id())){http_response_code(404);exit('Not found');}
if(!asset_file($d)){http_response_code(404);exit('File missing');}
if(($_SERVER['REQUEST_METHOD']??'GET')!=='HEAD' && !isset($_SERVER['HTTP_RANGE']))exec_sql('UPDATE downloads SET download_count=download_count+1 WHERE id=?',[$id]);
send_stored_file($d,true);
