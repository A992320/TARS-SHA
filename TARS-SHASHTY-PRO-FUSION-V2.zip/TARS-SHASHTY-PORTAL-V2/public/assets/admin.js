'use strict';
document.querySelectorAll('form[data-confirm]').forEach(form => form.addEventListener('submit', event => {
  if (!window.confirm(form.dataset.confirm || 'هل أنت متأكد؟')) event.preventDefault();
}));

const CHUNK_SIZE = 4 * 1024 * 1024;
for (const uploader of document.querySelectorAll('[data-upload-type]')) {
  const picker = uploader.querySelector('.file-picker');
  const progress = uploader.querySelector('.upload-progress');
  const bar = uploader.querySelector('.progress-bar span');
  const status = uploader.querySelector('.upload-message');
  const result = uploader.querySelector('.upload-result');
  const assetField = document.querySelector('.asset-id-field');
  const token = document.querySelector('input[name="csrf"]')?.value || '';
  let running = false;
  function say(text) { status.textContent = text; }
  async function post(fields) {
    const fd = new FormData(); fd.append('csrf', token);
    for (const [key, value] of Object.entries(fields)) fd.append(key, value);
    const response = await fetch('/api/upload.php', { method:'POST', body:fd, credentials:'same-origin' });
    const data = await response.json().catch(() => ({ ok:false, error:'استجابة غير صالحة من الخادم' }));
    if (!response.ok || !data.ok) throw new Error(data.error || 'تعذر الرفع');
    return data;
  }
  picker?.addEventListener('change', async () => {
    const file = picker.files?.[0];
    if (!file || running) return;
    running = true; progress.hidden = false; bar.style.width = '0%'; result.textContent = '';
    picker.disabled = true; let jobId = null;
    try {
      say('جاري إنشاء جلسة رفع مشفّرة بالجلسة...');
      const start = await post({action:'start', type:uploader.dataset.uploadType, name:file.name, size:String(file.size)});
      jobId = start.id;
      const total = Math.ceil(file.size / CHUNK_SIZE);
      for (let i = 0; i < total; i++) {
        const startPos = i * CHUNK_SIZE;
        const chunk = file.slice(startPos, Math.min(startPos + CHUNK_SIZE, file.size));
        let success = false;
        for (let attempt = 1; attempt <= 3 && !success; attempt++) {
          try { await post({action:'chunk', id:jobId, index:String(i), chunk}); success = true; }
          catch(error) { if (attempt === 3) throw error; await new Promise(resolve => setTimeout(resolve, attempt * 1200)); }
        }
        const pct = Math.round(((i + 1) / total) * 100);
        bar.style.width = pct + '%';
        say('رفع ' + pct + '% · ' + (i+1) + ' / ' + total + ' جزء');
      }
      say('جاري تأكيد اكتمال الملف...');
      const finished = await post({action:'finish', id:jobId});
      assetField.value = finished.asset_id;
      result.textContent = '✓ تم رفع ' + finished.name + ' بنجاح. اضغط «حفظ» لنشره.';
      result.classList.remove('upload-error'); say('اكتمل رفع الملف بنجاح');
    } catch(error) {
      result.textContent = '✕ ' + (error?.message || 'فشل رفع الملف') + ' — أعد اختيار الملف للمحاولة من البداية.';
      result.classList.add('upload-error'); say('تعذر إكمال الرفع');
      assetField.value = '';
    } finally { running = false; picker.disabled = false; picker.value = ''; }
  });
}
