 'use strict';
const toggle = document.getElementById('menuToggle');
const links = document.getElementById('navLinks');
function closeMenu() { links?.classList.remove('open'); toggle?.setAttribute('aria-expanded', 'false'); }
toggle?.addEventListener('click', () => {
  const open = links.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(open));
});
links?.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
document.addEventListener('click', e => {
  if (links?.classList.contains('open') && !links.contains(e.target) && !toggle?.contains(e.target)) closeMenu();
});
