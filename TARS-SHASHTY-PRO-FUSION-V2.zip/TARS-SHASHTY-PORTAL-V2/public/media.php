<?php
declare(strict_types=1);
require __DIR__.'/../app/stream.php';
$id=max(0,(int)($_GET['id']??0));
$v=fetch_one('SELECT v.published,a.* FROM videos v JOIN assets a ON a.id=v.asset_id WHERE v.id=?',[$id]);
if(!$v||(!(int)$v['published']&&!admin_id())){http_response_code(404);exit('Not found');}
send_stored_file($v,isset($_GET['download']));
