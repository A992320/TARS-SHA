<?php
declare(strict_types=1);

const BASE_DIR = __DIR__ . '/..';
const PRIVATE_DIR = BASE_DIR . '/storage/private';

function load_env(string $path): void {
    if (!is_readable($path)) return;
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        $parts = explode('=', $line, 2);
        if (count($parts) < 2 || !preg_match('/^[A-Z][A-Z0-9_]*$/', trim($parts[0]))) continue;
        $key = trim($parts[0]); $value = trim($parts[1]);
        if ((str_starts_with($value, '"') && str_ends_with($value, '"')) || (str_starts_with($value, "'") && str_ends_with($value, "'"))) $value = substr($value, 1, -1);
        if (getenv($key) === false) $_ENV[$key] = $value;
    }
}
load_env(BASE_DIR . '/.env');
function config(string $key, string $default = ''): string { return (string) (getenv($key) !== false ? getenv($key) : ($_ENV[$key] ?? $default)); }

if (PHP_SAPI !== 'cli') {
    ini_set('session.use_strict_mode', '1');
    session_name('TARSSESSID');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','httponly'=>true,'samesite'=>'Lax']);
    session_start();
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; media-src 'self'; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self'");
}

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', config('DB_HOST','127.0.0.1'), (int)config('DB_PORT','3306'), config('DB_NAME','tars_portal'));
    $pdo = new PDO($dsn, config('DB_USER','tars_portal'), config('DB_PASS'), [
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false, PDO::MYSQL_ATTR_MULTI_STATEMENTS=>false
    ]);
    return $pdo;
}
function fetch_one(string $sql, array $params=[]): ?array { $s=db()->prepare($sql); $s->execute($params); return $s->fetch() ?: null; }
function fetch_all(string $sql, array $params=[]): array { $s=db()->prepare($sql); $s->execute($params); return $s->fetchAll(); }
function exec_sql(string $sql, array $params=[]): int { $s=db()->prepare($sql); $s->execute($params); return $s->rowCount(); }
function e(?string $value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function nl(?string $value): string { return nl2br(e($value)); }
function csrf_token(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.e(csrf_token()).'">'; }
function verify_csrf(): void { $v=(string)($_POST['csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''); if ($v==='' || !hash_equals(csrf_token(), $v)) { http_response_code(419); exit('انتهت الجلسة أو رمز التحقق غير صحيح. حدّث الصفحة.'); } }
function redirect(string $url): never { header('Location: '.$url, true, 303); exit; }
function flash(string $message, string $type='success'): void { $_SESSION['flash']=['message'=>$message,'type'=>$type]; }
function take_flash(): ?array { $v=$_SESSION['flash']??null; unset($_SESSION['flash']); return $v; }
function admin_id(): ?int { return isset($_SESSION['admin_id']) ? (int)$_SESSION['admin_id'] : null; }
function require_admin(): void { if (!admin_id()) redirect('/admin.php?section=login'); }
function settings(): array { static $all = null; if ($all===null) { $all=[]; foreach(fetch_all('SELECT `key`,`value` FROM settings') as $s) $all[$s['key']]=$s['value']; } return $all; }
function setting(string $key, string $default=''): string { return (string)(settings()[$key] ?? $default); }
function int_post(string $key): int { return max(0, (int)($_POST[$key] ?? 0)); }
function bool_post(string $key): int { return isset($_POST[$key]) ? 1 : 0; }
function product_label(string $product): string { return ['tars'=>'TARS LOADBALANCE','shashety'=>'SHASHETY PRO','general'=>'عام','tools'=>'أدوات أخرى'][$product] ?? 'عام'; }
function bytes_human(int|float $b): string { $unit=['B','KB','MB','GB','TB']; $i=0; while ($b >= 1024 && $i < 4) {$b/=1024; $i++;} return number_format($b, $i===0?0:1).' '.$unit[$i]; }
function pretty_date(string $time): string { return date('Y/m/d', strtotime($time)); }
function ip_fingerprint(): string { return hash_hmac('sha256', (string)($_SERVER['REMOTE_ADDR']??'unknown'), config('APP_KEY','unset')); }
function asset_file(array $asset): ?string {
    $root = realpath(PRIVATE_DIR);
    $relative = (string)$asset['stored_path'];
    if (!$root || !preg_match('~^(videos|downloads)/[a-f0-9]{32}\\.[a-z0-9]+$~', $relative)) return null;
    $path = realpath($root . '/' . $relative);
    return $path && str_starts_with($path, $root . DIRECTORY_SEPARATOR) && is_file($path) ? $path : null;
}
function json_response(array $data, int $code=200): never { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function request_post(): bool { return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
function checked(mixed $v): string { return (bool)$v ? ' checked' : ''; }
function selected(mixed $v, mixed $compare): string { return (string)$v===(string)$compare ? ' selected' : ''; }
