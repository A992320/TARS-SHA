<?php
declare(strict_types=1);
require_once __DIR__.'/bootstrap.php';
function send_stored_file(array $asset, bool $asDownload): never {
    $path=asset_file($asset);
    if($path===null){http_response_code(404);exit('File not found');}
    $size=filesize($path);
    $name=basename((string)$asset['original_name']);
    $fallback=preg_replace('/[^a-zA-Z0-9._-]/','_', $name) ?: 'file.bin';
    $mime=$asDownload?'application/octet-stream':(string)$asset['mime'];
    header('Content-Type: '.$mime);
    header('X-Content-Type-Options: nosniff');
    header('Content-Disposition: '.($asDownload?'attachment':'inline').'; filename="'.$fallback.'"; filename*=UTF-8\'\''.rawurlencode($name));
    header('Accept-Ranges: bytes');
    header('Cache-Control: private, max-age=0, must-revalidate');
    if(config('X_ACCEL_REDIRECT','0')==='1') {
        header('X-Accel-Redirect: /_protected/'.(string)$asset['stored_path']);
        exit;
    }
    $start=0;$end=$size-1;
    if(isset($_SERVER['HTTP_RANGE'])) {
        $range=(string)$_SERVER['HTTP_RANGE'];
        if(!preg_match('/^bytes=(\d*)-(\d*)$/',$range,$m)||($m[1]===''&&$m[2]==='')) {
            header('Content-Range: bytes */'.$size);http_response_code(416);exit;
        }
        if($m[1]==='') {$suffix=(int)$m[2];$start=max(0,$size-$suffix);}
        else {$start=(int)$m[1];$end=$m[2]===''?$end:min($end,(int)$m[2]);}
        if($start>$end||$start>=$size){header('Content-Range: bytes */'.$size);http_response_code(416);exit;}
        http_response_code(206);header("Content-Range: bytes $start-$end/$size");
    }
    header('Content-Length: '.($end-$start+1));
    if(($_SERVER['REQUEST_METHOD']??'GET')==='HEAD')exit;
    while(ob_get_level()>0)ob_end_clean();
    set_time_limit(0);
    $h=fopen($path,'rb');if(!$h)exit;
    fseek($h,$start);$left=$end-$start+1;
    while($left>0&&!feof($h)&&!connection_aborted()) {
        $buffer=fread($h,min(1024*1024,$left));
        if($buffer===false||$buffer==='')break;
        echo $buffer;$left-=strlen($buffer);flush();
    }
    fclose($h);exit;
}
