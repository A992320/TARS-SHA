<?php
declare(strict_types=1);
require_once __DIR__.'/bootstrap.php';

function page_head(string $title='', bool $admin=false): void {
    $site=setting('site_title','TARS × SHASHETY PRO');
    $full=$title ? "$title | $site" : $site;
    $css=$admin?'/assets/admin.css':'/assets/site.css';
    echo '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#070c1c"><meta name="description" content="'.e(setting('site_subtitle','منصة TARS × SHASHETY PRO')).'"><title>'.e($full).'</title><link rel="icon" type="image/svg+xml" href="/assets/logo.svg"><link rel="stylesheet" href="'.$css.'"></head><body>';
}
function nav_public(string $active=''): void { ?>
    <header class="topbar" id="topbar"><div class="container nav-inner">
      <a href="/?page=home" class="brand brand-combined" aria-label="TARS × SHASHTY PRO — الرئيسية"><span class="logo-tars">T</span><span class="brand-cross">×</span><span class="logo-stream">▶</span><span class="brand-words"><strong>SHASHTY <em>PRO</em></strong><small>TARS LOADBALANCE × IPTV</small></span></a>
      <button class="nav-toggle" type="button" id="menuToggle" aria-expanded="false" aria-controls="navLinks" aria-label="فتح قائمة التنقل">☰</button>
      <nav class="nav-links" id="navLinks" aria-label="القائمة الرئيسية">
        <?php foreach ([['home','الرئيسية'],['shashety','شاشتي برو'],['tars','تارس'],['tutorials','الشروحات'],['downloads','التحميلات'],['articles','المقالات']] as $n): ?>
        <a class="<?= $active===$n[0]?'active':'' ?>" href="/?page=<?= $n[0] ?>"><?=e($n[1])?></a><?php endforeach; ?>
      </nav>
      <a href="/admin.php" class="nav-cta" aria-label="الانتقال إلى لوحة الإدارة"><span class="nav-user-icon">♙</span> الإدارة</a>
    </div></header>
<?php }
function public_footer(): void { ?>
  <footer class="footer"><div class="container"><div class="footer-top"><div class="footer-identity"><a href="/?page=home" class="footer-logo">TARS <span>×</span> SHASHTY PRO</a><p>منصة تجمع مشاريع إدارة الشبكات الذكية وحلول البث والمشاهدة، مع مكتبة الشروحات ومركز الإصدارات.</p></div><div class="footer-nav-grid"><div><strong>الأنظمة</strong><a href="/?page=tars">TARS LOADBALANCE</a><a href="/?page=shashety">SHASHTY PRO IPTV</a><a href="/?page=downloads">مركز التحميل</a></div><div><strong>المحتوى</strong><a href="/?page=tutorials">الشروحات</a><a href="/?page=articles">المقالات</a><a href="/admin.php">لوحة الإدارة</a></div></div></div><div class="footer-bottom"><span><?= e(setting('footer_text','TARS × SHASHTY PRO — جميع الحقوق محفوظة.')) ?></span><span>ONE PLATFORM · TWO SYSTEMS · <?=date('Y')?></span></div></div></footer>
  <script src="/assets/app.js" defer></script></body></html>
<?php }
function flash_notice(): void { if ($f=take_flash()): ?><div class="notice <?=e($f['type'])?>" role="status"><?=e($f['message'])?></div><?php endif; }
function section_intro(string $eyebrow,string $title,string $subtitle=''): void { ?><div class="section-intro"><span class="eyebrow"><?=e($eyebrow)?></span><h2><?=e($title)?></h2><?php if($subtitle):?><p><?=e($subtitle)?></p><?php endif;?></div><?php }
function category_card(array $c): void { ?>
 <a href="/?page=tutorials&amp;category=<?=(int)$c['id']?>" class="category-card"><span class="category-icon"><?=e($c['icon'])?></span><div><strong><?=e($c['title'])?></strong><p><?=e($c['description'])?></p></div><span class="arrow-icon">↗</span></a>
<?php }
function video_card(array $v): void { ?>
 <a class="content-card video-card" href="/?page=watch&amp;id=<?=(int)$v['id']?>"><div class="content-art video-art"><span class="video-play">▶</span><span class="art-stamp">VIDEO</span></div><div class="content-body"><small class="tag"><?=e($v['category_title']??'شروحات')?></small><h3><?=e($v['title'])?></h3><p><?=e(mb_strimwidth($v['description'],0,120,'…','UTF-8'))?></p><div class="card-meta"><span><?=pretty_date($v['created_at'])?></span><span><?=number_format((int)$v['views'])?> مشاهدة</span></div></div></a>
<?php }
function download_card(array $d): void { ?>
 <div class="download-card"><div class="download-icon"><?=strtolower(pathinfo($d['original_name'],PATHINFO_EXTENSION))==='iso'?'◉':'⬡'?></div><div class="download-main"><div class="download-title-row"><h3><?=e($d['title'])?></h3><?php if($d['version']):?><span class="version">v<?=e(ltrim($d['version'],'vV'))?></span><?php endif;?></div><p><?=e(mb_strimwidth($d['description'],0,180,'…','UTF-8'))?></p><div class="download-meta"><span><?=e(product_label($d['product']))?></span><span><?=e(strtoupper(pathinfo($d['original_name'],PATHINFO_EXTENSION)))?></span><span><?=bytes_human((int)$d['size_bytes'])?></span><span><?=number_format((int)$d['download_count'])?> تحميل</span></div></div><a href="/download.php?id=<?=(int)$d['id']?>" class="btn btn-small btn-primary" rel="nofollow">↓ تحميل</a></div>
<?php }
function article_card(array $a): void { ?><a href="/?page=article&amp;id=<?=(int)$a['id']?>" class="article-card"><span class="tag"><?=e($a['category_title']??'المعرفة')?></span><h3><?=e($a['title'])?></h3><p><?=e($a['summary'])?></p><div class="article-bottom"><time><?=pretty_date($a['created_at'])?></time><span>اقرأ المقال ←</span></div></a><?php }
